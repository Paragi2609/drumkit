//Javascript30 - Project #1 : Drum Kit  

function playSound(key, type){
    const charCode = getCharCode(key, type);  
  const soundClip = document.querySelector('audio[data-key="'+ charCode + '"]');
  if (!soundClip) return;
 const currentDiv = '[data-key="'+ charCode + '"]';
 document.querySelector(currentDiv).classList.add('playing');
  soundClip.currentTime = 0;
  soundClip.play();
}

// get the keycode from a keypress or click
function getCharCode(key, type) {
  if (type == "click") {
    return clickSoundClip(key);
  } else if (type == "press") {
    return pressSoundClip(key);
  }
}

function pressSoundClip(key) {
  const keyCode = key.keyCode;
  return keyCode;
}

function clickSoundClip(key) {
  const keyCode = key.path[1].getAttribute("data-key");
  return keyCode;
}

function removeClass(event){
  if(event.propertyName !== "transform"){return;}
  else {
    event.target.classList.remove("playing");
  }
} 


const keypad = Array.from(document.querySelectorAll(".key"));
keypad.forEach(key => key.addEventListener("transitionend", removeClass));

// Add an event listener to the entire window that listens for a keypress or click
window.addEventListener("keydown", function(key) {
  const type = "press";
  playSound(key, type);
});

window.addEventListener("click", function(key) {
  const type = "click";
playSound(key, type);
});

